// Put this in one place so we don't have to make massive changes when it is put somewhere else
import * as GuiSetup from '@ephox/alloy/lib/test/ts/module/ephox/alloy/test/GuiSetup';

import TestStore from '@ephox/alloy/lib/test/ts/module/ephox/alloy/test/TestStore';

export {
  GuiSetup,
  TestStore
};