/**
 * Copyright (c) Tiny Technologies, Inc. All rights reserved.
 * Licensed under the LGPL or a commercial license.
 * For LGPL see License.txt in the project root for license information.
 * For commercial licenses see https://www.tiny.cloud/
 */

import { Editor } from '../../../../../core/main/ts/api/Editor';
import ColorSwatch from '../ui/core/color/ColorSwatch';
import Settings from '../ui/core/color/Settings';
import { Menu } from '@ephox/bridge';
import { Option } from '@ephox/katamari';

type ColorInputCallback = (valueOpt: Option<string>) => void;

export interface UiFactoryBackstageForColorInput {
  colorPicker: (callback: ColorInputCallback, value: string) => void;
  hasCustomColors: () => boolean;
  getColors: () => Menu.ChoiceMenuItemApi[];
}

const colorPicker = (editor: Editor) => (callback: ColorInputCallback, value: string) => {
  const dialog = ColorSwatch.colorPickerDialog(editor);
  dialog(callback, value);
};

const hasCustomColors = (editor: Editor) => (): boolean => {
  return Settings.hasCustomColors(editor);
};

const getColors = (editor: Editor) => (): Menu.ChoiceMenuItemApi[] => {
  return Settings.getColors(editor);
};

export const ColorInputBackstage = (editor: Editor): UiFactoryBackstageForColorInput => ({
  colorPicker: colorPicker(editor),
  hasCustomColors: hasCustomColors(editor),
  getColors: getColors(editor)
});