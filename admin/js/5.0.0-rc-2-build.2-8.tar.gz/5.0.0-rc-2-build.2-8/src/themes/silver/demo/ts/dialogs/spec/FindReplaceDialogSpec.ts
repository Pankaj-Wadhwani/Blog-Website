import { SearchReplaceDialogSpec } from '../../components/searchreplace/SearchReplace';

export default SearchReplaceDialogSpec;