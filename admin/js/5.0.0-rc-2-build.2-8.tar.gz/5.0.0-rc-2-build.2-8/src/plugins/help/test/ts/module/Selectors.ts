export default {
  dialog: '[role="dialog"]',
  toolbarHelpButton: '.tox-toolbar button',
  pluginsTab: '[role="tab"]:contains(Plugins)'
};