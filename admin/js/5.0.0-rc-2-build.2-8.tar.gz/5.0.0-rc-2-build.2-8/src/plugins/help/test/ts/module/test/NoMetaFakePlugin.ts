import PluginManager from 'tinymce/core/api/PluginManager';

PluginManager.add('nometafake', function () {});

export default function () {}